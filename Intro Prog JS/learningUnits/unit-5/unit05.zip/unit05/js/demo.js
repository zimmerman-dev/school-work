function demoFunction() {
    "use strict";

    

}
