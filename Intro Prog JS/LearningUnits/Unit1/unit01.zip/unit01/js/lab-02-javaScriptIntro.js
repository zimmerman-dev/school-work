function lab02() {
    "use strict";

    // YOUR CODE STARTS AFTER THIS LINE

    // Delete this line before starting (for testing purposes)
    document.write("Lab 2");

    
}