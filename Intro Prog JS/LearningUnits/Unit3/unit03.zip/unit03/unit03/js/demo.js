function demoFunction() {
    "use strict";


}
